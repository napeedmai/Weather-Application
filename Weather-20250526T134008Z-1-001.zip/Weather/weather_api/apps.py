from django.apps import AppConfig


class WeatherApiConfig(AppConfig):
    name = 'weather_api'
