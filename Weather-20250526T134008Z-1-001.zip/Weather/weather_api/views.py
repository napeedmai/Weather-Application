from django.shortcuts import render, redirect
from weather_api.key import api_key
import requests
import math
from .models import weather
from .utils import get_db_handle
from django.http import HttpResponse
from pymongo import MongoClient


lang=""
# from .models import Social

# Create your views here.

def index(request):
    return render(request, "weather_api/home.html",{"view":0})


# def get_weather_data(request):
#     client = MongoClient('mongodb://localhost:27017/')
#     db = client['weather']
#     weather_collection = db['language']

#     # Retrieve data from MongoDB
#     weather_data = list(weather_collection.find({}))
#     print(weather_data)
#     return render(request, {'weather_data': weather_data})

def lange(request):
   
    if request.method == 'POST':
        print(request.POST)
        globals()['lang'] = request.POST['lang']
        # Store the selected language in a variable or session
        request.session['selected_language'] = globals()['lang'] 
        # return globals()['lang'] 
        return redirect('result')
date=()
def result(request):
    if request.method == "POST":
        city_name = request.POST["city"]
        name = request.POST['city']
        data = {
                "name": name}
        weather.insert_one(data)
        url = f"http://api.weatherapi.com/v1/current.json?key=2b73c716cd5e47aeb8a51520240609&q={city_name}&aqi=yes&lang={request.session['selected_language']}"
        w_dataset = requests.get(url).json()
        urlf = f"http://api.weatherapi.com/v1/forecast.json?key=2b73c716cd5e47aeb8a51520240609&q={city_name}&days=1&aqi=no&alerts=no"
        f_dataset = requests.get(urlf).json()
        #print(f_dataset["forecast"]["forecastday"][0]["hour"][0]["temp_c"] )
        try:
            time=w_dataset["current"]["last_updated"]
            date=int(time[8:10])
            print(date)

            
            hrs=int(time[11:13])
            lst=[]
            for i in range(6):
                l=[]
                hrs=hrs+3
                if hrs < 24:
                    lst.append([hrs,date])
                else:
                    lst.append([hrs-24,date+1])
            mins=time[14:]
            count=0
            for dates in lst:
                f_dataset["forecast"]["forecastday"][0]["hour"][lst[count][0]]["time"]="2024-09-"+str(dates[1])+" "+str(lst[count][0])+":"+str(mins)
                count+=1
            context = {
                    ####
                    "city_name":w_dataset["location"]["name"],
                    "city_country":w_dataset["location"]["region"],
                    "wind":w_dataset["current"]["wind_kph"],
                    "degree":w_dataset["current"]["wind_degree"],
                    "status":w_dataset["current"]["condition"]["text"],
                    "cloud":w_dataset["current"]["cloud"],
                    "date":w_dataset["current"]["last_updated"],
                    "date1":f_dataset["forecast"]["forecastday"][0]["hour"][lst[0][0]]["time"],
                    "date2":f_dataset["forecast"]["forecastday"][0]["hour"][lst[1][0]]["time"],
                    "date3":f_dataset["forecast"]["forecastday"][0]["hour"][lst[2][0]]["time"],
                    "date4":f_dataset["forecast"]["forecastday"][0]["hour"][lst[3][0]]["time"],
                    "date5":f_dataset["forecast"]["forecastday"][0]["hour"][lst[4][0]]["time"],
                    "date6":f_dataset["forecast"]["forecastday"][0]["hour"][lst[5][0]]["time"],

                    "temp": round(w_dataset["current"]["temp_c"]),
                    "temp_min1":round(f_dataset["forecast"]["forecastday"][0]["hour"][0]["temp_f"]),
                    "temp_max1":round(f_dataset["forecast"]["forecastday"][0]["hour"][0]["temp_c"]),
                    "temp_min2":round(f_dataset["forecast"]["forecastday"][0]["hour"][3]["temp_f"]),
                    "temp_max2":round(f_dataset["forecast"]["forecastday"][0]["hour"][3]["temp_c"]),
                    "temp_min3":round(f_dataset["forecast"]["forecastday"][0]["hour"][6]["temp_f"]),
                    "temp_max3":round(f_dataset["forecast"]["forecastday"][0]["hour"][6]["temp_c"]),
                    "temp_min4":round(f_dataset["forecast"]["forecastday"][0]["hour"][9]["temp_f"]),
                    "temp_max4":round(f_dataset["forecast"]["forecastday"][0]["hour"][9]["temp_c"]),
                    "temp_min5":round(f_dataset["forecast"]["forecastday"][0]["hour"][12]["temp_f"]),
                    "temp_max5":round(f_dataset["forecast"]["forecastday"][0]["hour"][12]["temp_c"]),
                    "temp_min6":round(f_dataset["forecast"]["forecastday"][0]["hour"][15]["temp_f"]),
                    "temp_max6":round(f_dataset["forecast"]["forecastday"][0]["hour"][15]["temp_c"]),

                    # "pressure":w_dataset["list"][0]["main"]["pressure"],
                    # "humidity":w_dataset["list"][0]["main"]["humidity"],
                    # "sea_level":w_dataset["list"][0]["main"]["sea_level"],


                    # "weather":w_dataset["list"][1]["weather"][0]["main"],
                    # "description":w_dataset["list"][1]["weather"][0]["description"],
                    "icon":w_dataset["current"]["condition"]["icon"],
                    "icon1":f_dataset["forecast"]["forecastday"][0]["hour"][0]["condition"]["icon"],
                    "icon2":f_dataset["forecast"]["forecastday"][0]["hour"][3]["condition"]["icon"],
                    "icon3":f_dataset["forecast"]["forecastday"][0]["hour"][6]["condition"]["icon"],
                    "icon4":f_dataset["forecast"]["forecastday"][0]["hour"][9]["condition"]["icon"],
                    "icon5":f_dataset["forecast"]["forecastday"][0]["hour"][12]["condition"]["icon"],
                    "icon6":f_dataset["forecast"]["forecastday"][0]["hour"][15]["condition"]["icon"],

                }
        except:
                context = {

                "city_name":"Not Found, Check your spelling..."
            }
        context_data = context
         
        globals()['date']=context_data.get("date", "Not Found")
        request.session['history_date'] = globals()['date'] 

        return render(request, "weather_api/results.html", {"context":context,"view":1})
    else:
        return redirect('home')
    

def history(request):
    if request.method == "POST":
        city_name=weather.find()
        city_names=""
        for i in city_name:
           city_names=i['name']
        print(request.session['history_date'])
        url = f"http://api.weatherapi.com/v1/current.json?key=2b73c716cd5e47aeb8a51520240609&q={city_names}&aqi=yes&lang={request.session['selected_language']}"
        w_dataset = requests.get(url).json()
        urlf = f"http://api.weatherapi.com/v1/forecast.json?key=2b73c716cd5e47aeb8a51520240609&q={city_names}&date={request.session['history_date']}&aqi=no&alerts=no&"
        f_dataset = requests.get(urlf).json()
        print(f_dataset["forecast"]["forecastday"][0]["hour"][0]["temp_c"] )
        try:
            time=w_dataset["current"]["last_updated"]
            date=int(time[8:10])
            print(date)

            
            hrs=int(time[11:13])
            lst=[]
            for i in range(6):
                l=[]
                hrs=hrs+3
                if hrs < 24:
                    lst.append([hrs,date])
                else:
                    lst.append([hrs-24,date+1])
            mins=time[14:]
            count=0
            for dates in lst:
                f_dataset["forecast"]["forecastday"][0]["hour"][lst[count][0]]["time"]="2024-09-"+str(dates[1])+" "+str(lst[count][0])+":"+str(mins)
                count+=1
            context = {
                    ####
                    "city_name":w_dataset["location"]["name"],
                    "city_country":w_dataset["location"]["region"],
                    "wind":w_dataset["current"]["wind_kph"],
                    "degree":w_dataset["current"]["wind_degree"],
                    "status":w_dataset["current"]["condition"]["text"],
                    "cloud":w_dataset["current"]["cloud"],
                    "date":w_dataset["current"]["last_updated"],
                    "date1":f_dataset["forecast"]["forecastday"][0]["hour"][lst[0][0]]["time"],
                    "date2":f_dataset["forecast"]["forecastday"][0]["hour"][lst[1][0]]["time"],
                    "date3":f_dataset["forecast"]["forecastday"][0]["hour"][lst[2][0]]["time"],
                    "date4":f_dataset["forecast"]["forecastday"][0]["hour"][lst[3][0]]["time"],
                    "date5":f_dataset["forecast"]["forecastday"][0]["hour"][lst[4][0]]["time"],
                    "date6":f_dataset["forecast"]["forecastday"][0]["hour"][lst[5][0]]["time"],

                    "temp": round(w_dataset["current"]["temp_c"]),
                    "temp_min1":round(f_dataset["forecast"]["forecastday"][0]["hour"][0]["temp_f"]),
                    "temp_max1":round(f_dataset["forecast"]["forecastday"][0]["hour"][0]["temp_c"]),
                    "temp_min2":round(f_dataset["forecast"]["forecastday"][0]["hour"][3]["temp_f"]),
                    "temp_max2":round(f_dataset["forecast"]["forecastday"][0]["hour"][3]["temp_c"]),
                    "temp_min3":round(f_dataset["forecast"]["forecastday"][0]["hour"][6]["temp_f"]),
                    "temp_max3":round(f_dataset["forecast"]["forecastday"][0]["hour"][6]["temp_c"]),
                    "temp_min4":round(f_dataset["forecast"]["forecastday"][0]["hour"][9]["temp_f"]),
                    "temp_max4":round(f_dataset["forecast"]["forecastday"][0]["hour"][9]["temp_c"]),
                    "temp_min5":round(f_dataset["forecast"]["forecastday"][0]["hour"][12]["temp_f"]),
                    "temp_max5":round(f_dataset["forecast"]["forecastday"][0]["hour"][12]["temp_c"]),
                    "temp_min6":round(f_dataset["forecast"]["forecastday"][0]["hour"][15]["temp_f"]),
                    "temp_max6":round(f_dataset["forecast"]["forecastday"][0]["hour"][15]["temp_c"]),

                    # "pressure":w_dataset["list"][0]["main"]["pressure"],
                    # "humidity":w_dataset["list"][0]["main"]["humidity"],
                    # "sea_level":w_dataset["list"][0]["main"]["sea_level"],


                    # "weather":w_dataset["list"][1]["weather"][0]["main"],
                    # "description":w_dataset["list"][1]["weather"][0]["description"],
                    "icon":w_dataset["current"]["condition"]["icon"],
                    "icon1":f_dataset["forecast"]["forecastday"][0]["hour"][0]["condition"]["icon"],
                    "icon2":f_dataset["forecast"]["forecastday"][0]["hour"][3]["condition"]["icon"],
                    "icon3":f_dataset["forecast"]["forecastday"][0]["hour"][6]["condition"]["icon"],
                    "icon4":f_dataset["forecast"]["forecastday"][0]["hour"][9]["condition"]["icon"],
                    "icon5":f_dataset["forecast"]["forecastday"][0]["hour"][12]["condition"]["icon"],
                    "icon6":f_dataset["forecast"]["forecastday"][0]["hour"][15]["condition"]["icon"],
            }
        except:
            context = {

            "city_name":"Not Found, Check your spelling..."
         }
        
        return render(request, "weather_api/history.html", {'w_dataset': w_dataset, 'f_dataset': f_dataset, "context":context,"view":1})
    else:
        return redirect('home')
# def social_links(request):
#     sl = Social.objects.all()
#     context = {
#          'sl': sl
#      }
#     return render(request, 'weather_api/base.html', context)
          