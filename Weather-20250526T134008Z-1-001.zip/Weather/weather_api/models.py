from django.db import models
from .db import db_conn
from datetime import datetime
# Create your models here.

weather = db_conn["city"]
# Create your models here.

# class Social(models.Model):
#     website_url = models.CharField(max_length=255, null=True, blank=True)
#     facebook_url = models.CharField(max_length=255, null=True, blank=True)
#     instagram_url = models.CharField(max_length=255, null=True, blank=True)
#     twitter_url = models.CharField(max_length=255, null=True, blank=True)
#     github_url = models.CharField(max_length=255, null=True, blank=True)
#     linkedin_url = models.CharField(max_length=255, null=True, blank=True)
#
#     def __str__(self):
#         return self.website_url
