from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="home"),
    path("lange", views.lange, name="lange"),
    path("result", views.result, name="result"),
    path("history", views.history, name="history")
    # path('social_links', views.social_links),
]
